# shoppingcart

An Online Course Adding Application using Spring Boot, JSP and Bootstrap 4 UI. Technologies.

An e-commerce shopping app to buy student programming courses online. Implemented Session to track the cart items and saving the items for later on
and adding to wish list.
