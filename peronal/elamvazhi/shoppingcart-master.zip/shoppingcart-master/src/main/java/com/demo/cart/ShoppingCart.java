package com.demo.cart;

import java.util.HashMap;

public class ShoppingCart {
	
	private HashMap<String , ShoppingCartItem> items = new HashMap<>();
	int noofitems = 0;
	
	public ShoppingCart() {
		items = new HashMap<String, ShoppingCartItem>();
	}
	
	public void add(String itemID) {
		
		
	}

}
